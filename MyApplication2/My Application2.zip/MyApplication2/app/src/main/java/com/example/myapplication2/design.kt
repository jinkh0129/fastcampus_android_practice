package com.example.myapplication2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class design : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_design)
    }
}